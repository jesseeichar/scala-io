package scalax.file

import collection.JavaConverters._
import scala.reflect.ClassTag
import java.nio.file.{Files => JFiles}
import scala.util.control.Exception._

class FileAttributes(path: Path) {
  import path.jpath
  def all(implicit linkOptions:Seq[LinkOption] = Seq.empty): Set[FileAttribute[Any]] = {
    val map = JFiles.readAttributes(jpath, "*", linkOptions:_*).asScala
    map.map{case (key,value) => FileAttributeImpl(key, value.asInstanceOf[Any])}.toSet
  }
  def apply[A](name: String)(implicit linkOptions:Seq[LinkOption] = Seq.empty): Option[A] = {
    Option(JFiles.getAttribute(jpath, name, linkOptions:_*).asInstanceOf[A])
  }
  def exists[A](att: FileAttribute[A])(implicit linkOptions:Seq[LinkOption] = Seq.empty): Boolean = {
    apply(att.name)(linkOptions) exists {_ == att.value}
  }

  def get[T <: BasicFileAttributes : ClassTag](implicit linkOptions:Seq[LinkOption] = Seq.empty): Option[T] =
    get(implicitly[ClassTag[T]].runtimeClass.asInstanceOf[Class[T]], linkOptions:_*)
  def get[T <: BasicFileAttributes](c: Class[T], linkOptions:LinkOption*): Option[T] = {
    catching(classOf[UnsupportedOperationException]).opt{JFiles.readAttributes(jpath, c, linkOptions:_*)}
  }

  def update[A](attribute:FileAttribute[A], linkOptions:LinkOption*): this.type = update(attribute.name, attribute.value, linkOptions:_*)
  def update(name: String, newVal: Any, linkOptions:LinkOption*): this.type = {
    JFiles.setAttribute(jpath, name, newVal, linkOptions:_*)
    this
  }

  def view[T <: FileAttributeView : ClassTag](implicit linkOptions:Seq[LinkOption] = Seq.empty): Option[T] = 
    view(implicitly[ClassTag[T]].runtimeClass.asInstanceOf[Class[T]], linkOptions:_*)
  def view[T <: FileAttributeView](c: Class[T], linkOptions:LinkOption*): Option[T] = {
    catching(classOf[UnsupportedOperationException]).opt{JFiles.getFileAttributeView(jpath, c, linkOptions:_*)}
  }
  
  def supportsView[T <: FileAttributeView : ClassTag]:Boolean = 
    supportsView(implicitly[ClassTag[T]].runtimeClass.asInstanceOf[Class[T]])
  def supportsView[T <: FileAttributeView](c:Class[T]):Boolean = {
    jpath.getFileSystem.getFileStores.asScala.exists(_.supportsFileAttributeView(c))
  }
  def supportsView(name:String):Boolean = supportedViewNames.exists(_ == name)
  def supportedViewNames: Set[String] = {
    jpath.getFileSystem.supportedFileAttributeViews.asScala.toSet
  }
}